"use client"

import { useUser } from "@/lib/user-context"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Users, User, Wrench } from "lucide-react"

export default function LoginPage() {
  const { login } = useUser()
  const router = useRouter()

  const handleCitizenLeaderLogin = () => {
    login("citizen-leader")
    router.push("/citizen-leader/dashboard")
  }

  const handleCitizenLogin = () => {
    login("citizen")
    router.push("/citizen-portal")
  }

  const handleWorkerLogin = () => {
    login("worker")
    router.push("/worker/dashboard")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted flex items-center justify-center p-6">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex h-16 w-16 items-center justify-center rounded-lg bg-primary text-primary-foreground font-bold mx-auto mb-6">
            C
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-3">Civilio</h1>
          <p className="text-lg text-muted-foreground">Select your access level to continue</p>
        </div>

        {/* Login Options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Citizen Leader */}
          <Card className="border border-border hover:shadow-lg transition-all cursor-pointer">
            <div onClick={handleCitizenLeaderLogin} className="p-8 flex flex-col items-center text-center space-y-6">
              <div className="h-20 w-20 rounded-lg bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center">
                <Users className="h-10 w-10 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-2">Citizen Leader</h2>
                <p className="text-muted-foreground mb-6 text-sm">
                  Access full city management dashboard, submit grievances, provide feedback
                </p>
              </div>
              <Button className="w-full bg-primary hover:bg-primary/90">Login as Leader</Button>
            </div>
          </Card>

          {/* Regular Citizen */}
          <Card className="border border-border hover:shadow-lg transition-all cursor-pointer">
            <div onClick={handleCitizenLogin} className="p-8 flex flex-col items-center text-center space-y-6">
              <div className="h-20 w-20 rounded-lg bg-gradient-to-br from-cyan-600 to-cyan-700 flex items-center justify-center">
                <User className="h-10 w-10 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-2">Regular Citizen</h2>
                <p className="text-muted-foreground mb-6 text-sm">
                  Submit complaints about city services and track grievance status
                </p>
              </div>
              <Button variant="outline" className="w-full bg-transparent">
                Login as Citizen
              </Button>
            </div>
          </Card>

          {/* Worker/Vendor */}
          <Card className="border border-border hover:shadow-lg transition-all cursor-pointer">
            <div onClick={handleWorkerLogin} className="p-8 flex flex-col items-center text-center space-y-6">
              <div className="h-20 w-20 rounded-lg bg-gradient-to-br from-orange-600 to-orange-700 flex items-center justify-center">
                <Wrench className="h-10 w-10 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-2">Worker/Vendor</h2>
                <p className="text-muted-foreground mb-6 text-sm">
                  Manage work orders, track tasks, and submit completion reports
                </p>
              </div>
              <Button variant="outline" className="w-full bg-transparent">
                Login as Worker
              </Button>
            </div>
          </Card>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center text-sm text-muted-foreground">
          <p>For more information, contact city administration</p>
        </div>
      </div>
    </div>
  )
}
